//Erstellt von Alex am 08.11.13

#include "GatterTyp.h";

GatterTyp::GatterTyp(){

}
