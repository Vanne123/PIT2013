//Erstellt von Alex am 08.11.13

#include "ListenElement.h";

ListenElement::ListenElement(){

	ListenElement::next = nullptr; //warum geht NULL nicht?
	//ListenElement::schaltwerkElement = nullptr;

}
