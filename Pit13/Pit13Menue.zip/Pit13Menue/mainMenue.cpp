//Testklasse fuer das Menue-Modul


#include "Menue.h"

int main(){

	Menue* menu = new Menue();
	menu->start();
	return 0;
}
